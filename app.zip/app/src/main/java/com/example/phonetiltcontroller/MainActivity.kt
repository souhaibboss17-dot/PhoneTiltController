package com.example.phonetiltcontroller

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.abs

class MainActivity : Activity(), SensorEventListener {
    private val appName = "PhoneTiltController"
    private val uuid: UUID = UUID.fromString("7a1c6e10-4e67-4f36-9f22-42e4e2d4a001")
    private var adapter: BluetoothAdapter? = null
    private var sensorManager: SensorManager? = null
    private var writer: PrintWriter? = null
    private var serverSocket: BluetoothServerSocket? = null
    private var socket: BluetoothSocket? = null
    private lateinit var status: TextView
    private lateinit var angleText: TextView
    private lateinit var roleSpinner: Spinner
    private var role = "Controller (Redmi)"
    private var lastAngle = 0f
    private var center = 0f
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = BluetoothAdapter.getDefaultAdapter()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "🏎️ Phone Tilt Controller"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        roleSpinner = Spinner(this)
        roleSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Controller (Redmi)", "Receiver (Galaxy A07)"))
        status = TextView(this).apply { text = "1) اختَر وضع الهاتف  2) اضغط Start"; textSize = 16f; gravity = Gravity.CENTER }
        angleText = TextView(this).apply { text = "الميل: 0°"; textSize = 30f; gravity = Gravity.CENTER }
        val start = Button(this).apply { text = "Start / اتصال"; setOnClickListener { startRole() } }
        val calibrate = Button(this).apply { text = "معايرة الوسط"; setOnClickListener { center = lastAngle; status.text = "تم ضبط الوسط. خلّي الهاتف مستقيم." } }
        val stop = Button(this).apply { text = "Stop"; setOnClickListener { stopAll() } }
        val note = TextView(this).apply {
            text = "نسخة تجريبية: ترسل زاوية الميل عبر Bluetooth وتعرضها على الهاتف الثاني. لا تتحكم مباشرةً في Rally Fury بعد؛ اللعبة لا تسمح عادةً لتطبيق عادي باستبدال مستشعرها."
            textSize = 14f
        }
        layout.addView(title); layout.addView(roleSpinner); layout.addView(start)
        layout.addView(calibrate); layout.addView(stop); layout.addView(status); layout.addView(angleText); layout.addView(note)
        setContentView(layout)
    }

    private fun hasBtPermission(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val ok = checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        if (!ok) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE), 44)
        return ok
    }

    private fun startRole() {
        if (adapter == null) { status.text = "هذا الهاتف لا يدعم Bluetooth."; return }
        if (!hasBtPermission()) { status.text = "اسمح بصلاحيات Bluetooth ثم اضغط Start مرة أخرى."; return }
        if (adapter?.isEnabled != true) { status.text = "فعّل Bluetooth في إعدادات الهاتف."; return }
        role = roleSpinner.selectedItem.toString()
        running = true
        if (role.startsWith("Controller")) startSensor() else startReceiver()
    }

    private fun startSensor() {
        val sensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (sensor == null) { status.text = "لا يوجد مستشعر تسارع."; return }
        val paired = try { adapter?.bondedDevices?.toList() } catch (_: SecurityException) { null }
        if (paired.isNullOrEmpty()) { status.text = "اقرن الهاتفين أولاً من إعدادات Bluetooth."; return }
        sensorManager?.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
        status.text = "جارٍ الاتصال بالهاتف المقترن… افتح Receiver على Galaxy A07."
        thread {
            try {
                val device = paired.first()
                val s = device.createRfcommSocketToServiceRecord(uuid)
                socket = s
                adapter?.cancelDiscovery()
                s.connect()
                writer = PrintWriter(s.outputStream, true)
                runOnUiThread { status.text = "متصل! ميّل الهاتف يمين ويسار." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "فشل الاتصال. افتح Receiver على الهاتف الآخر وتأكد من الاقتران. ${e.message ?: ""}" }
            }
        }
    }

    private fun startReceiver() {
        thread {
            try {
                val device = adapter?.bondedDevices?.firstOrNull()
                if (device == null) { runOnUiThread { status.text = "اقرن الهاتفين من إعدادات Bluetooth أولاً." }; return@thread }
                val s = adapter!!.listenUsingRfcommWithServiceRecord(appName, uuid)
                serverSocket = s
                runOnUiThread { status.text = "بانتظار المقود… افتح Controller على Redmi." }
                val accepted = s.accept()
                socket = accepted
                val reader = BufferedReader(InputStreamReader(accepted.inputStream))
                runOnUiThread { status.text = "متصل بالمقود!" }
                while (running) {
                    val line = reader.readLine() ?: break
                    val value = line.toFloatOrNull() ?: continue
                    runOnUiThread { angleText.text = "الميل: ${"%.1f".format(value)}°" }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "تعذر الاستقبال: ${e.message ?: "خطأ Bluetooth"}" }
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!running || !role.startsWith("Controller")) return
        val angle = Math.toDegrees(kotlin.math.atan2(event.values[0].toDouble(), event.values[1].toDouble())).toFloat() - center
        lastAngle = angle
        angleText.text = "الميل: ${"%.1f".format(angle)}°"
        try { writer?.println(angle) } catch (_: Exception) {}
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun stopAll() {
        running = false
        sensorManager?.unregisterListener(this)
        try { writer?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        writer = null; socket = null; serverSocket = null
        status.text = "تم الإيقاف."
    }

    override fun onDestroy() { stopAll(); super.onDestroy() }
}
